# BBMS: Step-by-Step Implementation Guide
## Practical, Hands-On Refactoring Instructions

---

## 🎯 GOAL
Transform your working BBMS into a **professional, secure, software-engineered project** in 4 weeks.

---

## WEEK 1: SECURITY HARDENING (The Most Critical Week)

### DAY 1-2: Prepared Statements Foundation

#### What is the Problem?
Your current code:
```php
$username=$_POST['username'];
$password=$_POST['password'];
$query="SELECT * FROM admin WHERE username='$username' AND password='$password'";
$result=mysqli_query($conn , $query );
```

An attacker can login by entering username as: `admin' OR '1'='1`

This turns the query into:
```sql
SELECT * FROM admin WHERE username='admin' OR '1'='1' AND password=...
```

This ALWAYS returns true, and attacker gets in!

---

#### The Solution: Prepared Statements
```php
$username=$_POST['username'];
$password=$_POST['password'];

// Step 1: Create query with placeholders (?)
$query = "SELECT * FROM admin WHERE username=? AND password=?";

// Step 2: Prepare the query (Tell MySQL: "I'll send data separately")
$stmt = mysqli_prepare($conn, $query);

// Step 3: Bind variables to placeholders
// "ss" means: string, string
mysqli_stmt_bind_param($stmt, "ss", $username, $password);

// Step 4: Execute with data safely separated from query
mysqli_stmt_execute($stmt);

// Step 5: Get the result
$result = mysqli_stmt_get_result($stmt);
```

**Why it works:**
- SQL structure is fixed first
- User input is treated as DATA, never as code
- Even if attacker enters `admin' OR '1'='1`, it's treated as a literal string

---

### ✅ TASK 1.1: Fix admin/login.php

**File Location:** `admin/login.php`

**BEFORE (Current Code):**
```php
<?php
session_start();
include "../config/config.php";

if(isset($_POST['login'])){
    $username=$_POST['username'];
    $password=$_POST['password'];
    $query="SELECT * FROM admin WHERE username='$username' AND password='$password' ";
    $result=mysqli_query($conn , $query );

    if(mysqli_num_rows($result)==1){
        header("Location:dashboard.php");
    }
    else{
        echo "Invalid Login";
    }
}
?>
```

**AFTER (Fixed Code):**
```php
<?php
/**
 * Admin Login
 * Handles authentication for blood bank staff
 */

session_start();
include "../config/config.php";

$error = null;

if(isset($_POST['login'])){
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    
    // Validate input
    if(empty($username) || empty($password)){
        $error = "Username and password are required.";
    }
    else {
        // SECURITY: Use prepared statement
        $query = "SELECT * FROM admin WHERE username=? AND password=?";
        $stmt = mysqli_prepare($conn, $query);
        
        // Bind parameters (ss = string, string)
        mysqli_stmt_bind_param($stmt, "ss", $username, $password);
        
        // Execute safely
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        
        if(mysqli_num_rows($result) == 1){
            // Success - set session and redirect
            $admin = mysqli_fetch_assoc($result);
            $_SESSION['admin_id'] = $admin['admin_id'];
            $_SESSION['admin_name'] = $admin['name'];
            header("Location: dashboard.php");
            exit();
        }
        else{
            $error = "Invalid username or password.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Blood Bank - Admin Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #003366, #004d99);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0;
        }
        
        .login-container {
            background: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
        }
        
        h2 {
            color: #003366;
            text-align: center;
            margin-bottom: 30px;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        label {
            display: block;
            margin-bottom: 5px;
            color: #333;
            font-weight: 600;
        }
        
        input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            box-sizing: border-box;
        }
        
        input:focus {
            outline: none;
            border-color: #003366;
            box-shadow: 0 0 5px rgba(0, 51, 102, 0.3);
        }
        
        button {
            width: 100%;
            padding: 10px;
            background-color: #003366;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            margin-top: 20px;
        }
        
        button:hover {
            background-color: #002244;
        }
        
        .error {
            background-color: #f8d7da;
            color: #721c24;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 20px;
            text-align: center;
        }
    </style>
</head>

<body>
    <div class="login-container">
        <h2>🩸 Blood Bank Login</h2>
        
        <?php if($error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label for="username">Username</label>
                <input 
                    type="text" 
                    id="username" 
                    name="username" 
                    placeholder="Enter username"
                    required
                >
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <input 
                    type="password" 
                    id="password" 
                    name="password" 
                    placeholder="Enter password"
                    required
                >
            </div>
            
            <button type="submit" name="login">Login</button>
        </form>
    </div>
</body>
</html>
```

**How to Apply:**
1. Open `admin/login.php`
2. Replace entire content with AFTER code
3. Test:
   - Try login with username: `admin`
   - Try login with username: `admin' OR '1'='1` (should fail)
   - Try valid password

---

### ✅ TASK 1.2: Create Session Check File

**New File:** `admin/session_check.php`

**Code:**
```php
<?php
/**
 * Session Check & Security
 * 
 * Include this file at the top of every protected page
 * It will:
 * 1. Start session
 * 2. Check if user is logged in
 * 3. Redirect to login if not
 */

session_start();

// Check if admin is logged in
if(!isset($_SESSION['admin_id'])){
    // User not logged in - redirect to login page
    header("Location: ../admin/login.php");
    exit(); // IMPORTANT: Stop executing current page
}

// Optional: Check if session is expired (30 minutes)
// You can add this later

?>
```

**How to Apply:**
1. Create new file: `admin/session_check.php`
2. Copy the code above
3. Save

---

### ✅ TASK 1.3: Update donor/add_donor.php with Session Check

**File Location:** `donor/add_donor.php`

**What to Change:**
1. Add this as FIRST line of PHP code:
   ```php
   require_once("../admin/session_check.php");
   ```

2. Replace the database query with prepared statement:

**BEFORE:**
```php
if(isset($_POST['submit']))
{
    $name = $_POST['name'];
    $age = $_POST['age'];
    // ... more code ...
    
    $query = "INSERT INTO donor(name,age,gender,blood_group,phone,address)
    VALUES('$name','$age','$gender','$blood_group','$phone','$address')";
    
    mysqli_query($conn,$query);
    
    echo "Donor added successfully";
}
```

**AFTER:**
```php
if(isset($_POST['submit']))
{
    $name = trim($_POST['name']);
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $blood_group = $_POST['blood_group'];
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    
    // Use prepared statement
    $query = "INSERT INTO donor(name,age,gender,blood_group,phone,address) 
              VALUES(?,?,?,?,?,?)";
    $stmt = mysqli_prepare($conn, $query);
    
    if(!$stmt){
        $error = "Database error: " . mysqli_error($conn);
    }
    else {
        // Bind: s=string, i=integer
        mysqli_stmt_bind_param($stmt, "sisisss", $name, $age, $gender, $blood_group, $phone, $address);
        
        if(mysqli_stmt_execute($stmt)){
            echo "Donor added successfully";
        }
        else {
            $error = "Error adding donor: " . mysqli_stmt_error($stmt);
        }
        
        mysqli_stmt_close($stmt);
    }
}
```

---

### ✅ TASK 1.4: Create Validation Helper File

**New File:** `helpers/validation.php`

**Code:**
```php
<?php
/**
 * Input Validation Helper Class
 * 
 * Provides methods to validate donor, patient, and blood data
 * Prevents invalid data from entering database
 */

class InputValidator {
    
    /**
     * Validate donor/patient name
     * Rules: Only letters and spaces, max 100 chars
     */
    public static function validateName($name) {
        // Check if empty
        if(empty(trim($name))) {
            return false;
        }
        
        // Check length
        if(strlen($name) > 100) {
            return false;
        }
        
        // Check format (only letters and spaces)
        if(!preg_match("/^[a-zA-Z\s]+$/", $name)) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Validate age
     * Rules: Must be number, 18-100
     */
    public static function validateAge($age) {
        // Check if numeric
        if(!is_numeric($age)) {
            return false;
        }
        
        $age = intval($age);
        
        // Check range
        if($age < 18 || $age > 100) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Validate phone number
     * Rules: 10-15 digits only
     */
    public static function validatePhone($phone) {
        // Check length
        if(strlen($phone) < 10 || strlen($phone) > 15) {
            return false;
        }
        
        // Check format (only digits)
        if(!preg_match("/^[0-9]{10,15}$/", $phone)) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Validate blood group
     * Rules: Must be one of 8 valid groups
     */
    public static function validateBloodGroup($blood_group) {
        $valid_groups = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];
        return in_array($blood_group, $valid_groups);
    }
    
    /**
     * Validate quantity
     * Rules: Must be positive number
     */
    public static function validateQuantity($quantity) {
        // Check if numeric
        if(!is_numeric($quantity)) {
            return false;
        }
        
        $quantity = floatval($quantity);
        
        // Check if positive
        if($quantity <= 0) {
            return false;
        }
        
        return true;
    }
}

?>
```

**How to Apply:**
1. Create folder: `helpers` (if doesn't exist)
2. Create file: `helpers/validation.php`
3. Copy code above
4. Save

---

### ✅ TASK 1.5: Update donor/add_donor.php with Validation

**Where to Add Validation:**

In your form submission code, add validation BEFORE database insert:

```php
if(isset($_POST['submit'])){
    require_once("../helpers/validation.php");
    
    $name = trim($_POST['name']);
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $blood_group = $_POST['blood_group'];
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    
    // VALIDATE each field
    $error = null;
    
    if(!InputValidator::validateName($name)){
        $error = "Invalid name. Use letters only.";
    }
    elseif(!InputValidator::validateAge($age)){
        $error = "Age must be between 18 and 100.";
    }
    elseif(!InputValidator::validatePhone($phone)){
        $error = "Phone must be 10-15 digits.";
    }
    elseif(!InputValidator::validateBloodGroup($blood_group)){
        $error = "Invalid blood group.";
    }
    
    // Only insert if no errors
    if(!$error){
        // ... INSERT CODE HERE ...
    }
    else {
        echo "Error: " . $error;
    }
}
```

---

### ✅ TASK 1.6: Protect All Pages with Session Check

**Apply to these files:**

```
✓ donor/add_donor.php
✓ donor/view_donor.php
✓ donor/delete_donor.php
✓ patient/add_patient.php
✓ patient/view_patient.php
✓ patient/delete_patient.php
✓ blood_donation/add_donation.php
✓ blood_donation/view_donation.php
✓ blood_request/add_request.php
✓ blood_request/view_request.php
✓ blood_request/approve_request.php
✓ blood_request/reject_request.php
✓ blood_inventory/view_inventory.php
```

**For each file:**
1. Open file
2. Add as FIRST PHP line:
   ```php
   require_once("../admin/session_check.php");
   ```
3. Save

---

### ✅ TEST WEEK 1 IMPROVEMENTS

**Test Case 1: SQL Injection Protection**
- Open admin/login.php
- Try username: `admin' OR '1'='1`
- Try password: anything
- Expected: "Invalid username or password" (NOT logged in)
- Result: ✅ Pass / ❌ Fail

**Test Case 2: Session Protection**
- Logout
- Type URL directly: `http://localhost/bloodbank/donor/view_donor.php`
- Expected: Redirected to login.php
- Result: ✅ Pass / ❌ Fail

**Test Case 3: Validation**
- Go to add donor
- Enter name: "John123" (has numbers)
- Expected: Error message "Invalid name"
- Result: ✅ Pass / ❌ Fail

**Test Case 4: Normal Login Still Works**
- Login with correct credentials
- Expected: Redirected to dashboard
- Result: ✅ Pass / ❌ Fail

---

## WEEK 2: ADD MISSING FEATURES

### DAY 3: Create Navigation Template

**New File:** `templates/navbar.php`

```php
<?php
/**
 * Navigation Bar Component
 * Include this in every page for consistent navigation
 */
?>

<style>
.navbar {
    background-color: #003366;
    padding: 15px 20px;
    margin-bottom: 20px;
}

.navbar a {
    color: white;
    text-decoration: none;
    margin-right: 15px;
    padding: 8px 12px;
    display: inline-block;
    border-radius: 4px;
    transition: 0.3s;
}

.navbar a:hover {
    background-color: #005599;
}

.navbar .logout {
    color: #ff6666;
    float: right;
}
</style>

<nav class="navbar">
    <a href="../admin/dashboard.php">📊 Dashboard</a>
    <a href="../donor/add_donor.php">➕ Add Donor</a>
    <a href="../donor/view_donor.php">👥 View Donors</a>
    <a href="../patient/add_patient.php">➕ Add Patient</a>
    <a href="../patient/view_patient.php">👥 View Patients</a>
    <a href="../blood_donation/add_donation.php">🩸 Add Donation</a>
    <a href="../blood_donation/view_donation.php">📋 View Donations</a>
    <a href="../blood_request/add_request.php">🏥 Add Request</a>
    <a href="../blood_request/view_request.php">📋 View Requests</a>
    <a href="../blood_inventory/view_inventory.php">📦 Inventory</a>
    <a href="../admin/logout.php" class="logout">🚪 Logout</a>
</nav>
```

**How to Apply:**
1. Create folder: `templates` (if doesn't exist)
2. Create file: `templates/navbar.php`
3. Copy code above
4. In every file, replace the navbar HTML with:
   ```php
   <?php include "../templates/navbar.php"; ?>
   ```

---

### DAY 4-5: Add UPDATE Operations

**Create File:** `donor/edit_donor.php`

[See the detailed code in the main review guide - copy from there]

Key changes:
1. Add session check
2. Get donor by ID
3. Show form with current data
4. Update on submit

**Then apply same pattern to:** `patient/edit_patient.php`

---

### DAY 5-6: Fix Table Name Typo

**Problem:** Table is named `blood_donotion` (typo)
**Solution:** Rename to `blood_donation`

**SQL Command:**
```sql
RENAME TABLE blood_donotion TO blood_donation;
```

**Update files:**
- `blood_donation/add_donation.php`
- `blood_donation/view_donation.php`

Replace all `blood_donotion` with `blood_donation`

---

## WEEK 3: CODE QUALITY

### Update All Files with Navbar

Replace inline navbar HTML in these files with:
```php
<?php include "../templates/navbar.php"; ?>
```

Files to update:
- donor/add_donor.php
- donor/view_donor.php
- patient/add_patient.php
- patient/view_patient.php
- blood_donation/add_donation.php
- blood_donation/view_donation.php
- blood_request/add_request.php
- blood_request/view_request.php
- blood_inventory/view_inventory.php

---

## WEEK 4: TESTING & DOCUMENTATION

### Create Test Cases Document

Create file: `tests/test_cases.md`

Format:
```markdown
# Test Cases

## Test Case 1: Admin Login
**ID:** TC_001
**Description:** Verify admin login with valid credentials
**Precondition:** Admin account exists
**Steps:**
1. Open login page
2. Enter username: admin
3. Enter password: correct password
4. Click Login
**Expected Result:** Redirected to dashboard

**Test Date:** ___
**Status:** ✅ Pass / ❌ Fail
**Notes:** ___

---

(Create similar for 15+ test cases)
```

---

## 🎓 LEARNING SUMMARY

### Prepared Statements Pattern

**Remember this pattern:**

```php
// 1. Define query with placeholders
$query = "SELECT * FROM table WHERE id = ? AND name = ?";

// 2. Prepare it
$stmt = mysqli_prepare($conn, $query);

// 3. Bind variables
mysqli_stmt_bind_param($stmt, "is", $id, $name);
// "is" = integer, string (must match order)

// 4. Execute
mysqli_stmt_execute($stmt);

// 5. Get result
$result = mysqli_stmt_get_result($stmt);

// 6. Use result
while($row = mysqli_fetch_assoc($result)) {
    // ...
}

// 7. Close
mysqli_stmt_close($stmt);
```

---

### Session Management Pattern

```php
// At top of EVERY protected page
require_once("../admin/session_check.php");

// To set session (after login)
session_start();
$_SESSION['admin_id'] = 1;
header("Location: dashboard.php");

// To clear session (on logout)
session_start();
session_destroy();
header("Location: login.php");
```

---

### Input Validation Pattern

```php
if(isset($_POST['submit'])){
    // Get and trim input
    $input = trim($_POST['field']);
    
    // Validate using helper class
    if(!InputValidator::validateName($input)){
        $error = "Invalid format";
    }
    else {
        // Use in database safely
        // Use prepared statement!
    }
}
```

---

### Displaying Data Safely

```php
// WRONG (XSS vulnerability)
echo "<p>" . $_POST['name'] . "</p>";

// RIGHT (Safe)
echo "<p>" . htmlspecialchars($_POST['name']) . "</p>";
```

---

## 📞 COMMON ERRORS & FIXES

### Error 1: "mysqli_fetch_assoc() expects parameter 1 to be mysqli_result"

**Cause:** Query failed or didn't return result

**Fix:**
```php
// WRONG
$result = mysqli_query($conn, "SELECT * FROM nonexistent_table");
while($row = mysqli_fetch_assoc($result)) {
    // Error here
}

// RIGHT
$result = mysqli_query($conn, "SELECT * FROM donor");
if($result) {
    while($row = mysqli_fetch_assoc($result)) {
        // ...
    }
}
else {
    echo "Error: " . mysqli_error($conn);
}
```

---

### Error 2: "Call to undefined function session_start()"

**Cause:** Missing at top of file

**Fix:** Add as FIRST line in PHP:
```php
<?php
session_start();
// rest of code
```

---

### Error 3: "Undefined index 'admin_id'"

**Cause:** Accessing $_POST or $_GET key that wasn't sent

**Fix:**
```php
// WRONG
$value = $_POST['field']; // Error if 'field' doesn't exist

// RIGHT
$value = $_POST['field'] ?? null; // Returns null if doesn't exist

// Or
if(isset($_POST['field'])){
    $value = $_POST['field'];
}
```

---

## ✅ COMPLETION CHECKLIST

After all 4 weeks:

- [ ] All files use prepared statements
- [ ] All protected pages have session check
- [ ] All inputs are validated
- [ ] All files include navbar template
- [ ] Edit operations work for donor/patient
- [ ] Table name typo is fixed
- [ ] Search functionality is added
- [ ] Test cases are documented (15+)
- [ ] Deployment guide is written
- [ ] Code is commented
- [ ] No SQL injection vulnerabilities
- [ ] No XSS vulnerabilities
- [ ] Login/logout works correctly
- [ ] Database backup created
- [ ] README updated with instructions

**If all checked → You're ready for submission! 🎉**

---

## 📈 ESTIMATED EFFORT

- Week 1 (Security): 4-5 hours
- Week 2 (Features): 6-7 hours
- Week 3 (Quality): 4-5 hours
- Week 4 (Testing): 5-6 hours

**Total: 19-23 hours over 4 weeks**

**Effort: ~5 hours/week or 1 hour/day**

---

**Good luck with your refactoring! You've got this! 🚀**

