# Blood Bank Management System (BBMS)
## Comprehensive Project Review & SDLC-Based Improvement Guide

---

## EXECUTIVE SUMMARY

Your BBMS project has a **solid foundation** with proper planning (SRS, ER diagram, Database design). However, the **implementation has critical gaps** from a Software Engineering perspective. This guide will help you bridge those gaps systematically.

### Current Status: ✅ Good Planning | ⚠️ Implementation Needs Improvement

---

## PHASE 1: ANALYSIS OF CURRENT STATE

### 1.1 What You've Done Well ✅

| Aspect | Status | Evidence |
|--------|--------|----------|
| **Requirements Documentation** | ✅ Strong | Well-defined SRS with functional & non-functional requirements |
| **Database Design** | ✅ Good | Proper schema with tables, keys, and relationships |
| **ER Diagram** | ✅ Complete | Clear relationships between entities |
| **DFD (Data Flow)** | ✅ Present | Level 0 and Level 1 diagrams documented |
| **Folder Structure** | ✅ Organized | Modular organization (donor, patient, blood_donation, etc.) |
| **Core CRUD Operations** | ✅ Implemented | Add, View, Delete operations for main modules |

---

### 1.2 Critical Gaps & Issues ⚠️

#### **A. SECURITY ISSUES (CRITICAL)**

```
VULNERABILITY: SQL Injection
Location: Multiple files (login.php, add_donation.php, add_request.php, etc.)

PROBLEM:
$username=$_POST['username'];
$query="SELECT * FROM admin WHERE username='$username' AND password='$password'";
mysqli_query($conn , $query );

DANGER: User input directly concatenated into SQL query
RISK: Attacker can manipulate database, steal data, delete records
```

**Affected Files:**
- admin/login.php
- donor/add_donor.php
- patient/add_patient.php
- blood_donation/add_donation.php
- blood_request/add_request.php

---

#### **B. SESSION MANAGEMENT ISSUES**

```
PROBLEM 1: No Session Verification
- Pages like donor/view_donor.php, patient/add_patient.php don't check if user is logged in
- Anyone can access these pages by typing URL directly
- No session_start() in most files

PROBLEM 2: Weak Login Implementation
- admin/login.php has no session creation after successful login
- Passwords stored in PLAIN TEXT (massive security risk!)
- No logout functionality verification
```

---

#### **C. INPUT VALIDATION MISSING**

```
PROBLEM: No validation before database insertion

EXAMPLE (add_donor.php):
$name = $_POST['name'];
$age = $_POST['age'];
... inserted directly into database

WHAT IF:
- User submits HTML/JavaScript in name field?
- User submits negative age?
- User submits empty fields?
```

---

#### **D. ERROR HANDLING GAPS**

```
PROBLEM: No error checking for database operations

EXAMPLE (add_donation.php):
mysqli_query($conn,"INSERT INTO blood_donotion(...)");
echo "Donation added and inventory updated.";

ISSUE:
- No check if query succeeded or failed
- Typo: "blood_donotion" vs "blood_donation" (inconsistent naming)
- Generic success message even if insert failed
```

---

#### **E. CODE DUPLICATION & MAINTENANCE ISSUES**

```
PROBLEM 1: Navigation Bar Repeated 10+ Times
- Blue navbar code duplicated in every file
- Changes require editing multiple files
- Perfect candidate for include/template

PROBLEM 2: Database Connection Repeated
- config.php included separately with different syntax
- Some use include "../config/config.php"
- Some use require_once "../config/config.php"
- Inconsistent approach

PROBLEM 3: HTML Structure Issues
- Some files have DOCTYPE and <html> tags
- Some don't
- Inconsistent table styling (table border="2" vs border="1")
```

---

#### **F. MISSING FEATURES (From SRS)**

Based on your SRS document, these are MISSING in implementation:

| Feature | Status | Issue |
|---------|--------|-------|
| Donor UPDATE operation | ❌ Missing | Only ADD and DELETE, no EDIT |
| Patient UPDATE operation | ❌ Missing | Only ADD and DELETE, no EDIT |
| Donation history tracking | ⚠️ Partial | View exists, but no filtering/search |
| Request history tracking | ✅ Exists | View exists with approval/rejection |
| Blood inventory alerts | ❌ Missing | No warning for low stock |
| Password encryption | ❌ Missing | SRS requires it, not implemented |
| Database backup mechanism | ❌ Missing | SRS requirement not implemented |

---

#### **G. DATABASE INCONSISTENCIES**

```
PROBLEM 1: Typo in Table Name
Your code uses: blood_donotion (WRONG spelling)
Should be: blood_donation

PROBLEM 2: Missing Foreign Keys
Database design shows foreign keys, but actual creation script missing
SRS mentions: donation_id has inventory_id FK (not implemented in code)

PROBLEM 3: Missing Constraints
No NOT NULL, UNIQUE, or CHECK constraints
For example: blood_group should be ENUM or have CHECK constraint
```

---

#### **H. TESTING & DOCUMENTATION**

```
MISSING:
- No unit test cases
- No test data/fixtures
- No API documentation
- No code comments explaining logic
- No deployment instructions
- No troubleshooting guide
```

---

## PHASE 2: ROADMAP FOR IMPROVEMENT

### Priority 1: SECURITY FIXES (Do First!)
**Estimated Time: 4-6 hours**

1. Replace MySQLi with Prepared Statements
2. Implement Session Management
3. Add Input Validation
4. Hash Passwords (SHA-256 or bcrypt)

### Priority 2: MISSING FEATURES (Core Functionality)
**Estimated Time: 6-8 hours**

1. Add UPDATE operations for Donor and Patient
2. Implement low stock alerts
3. Add search/filter functionality
4. Fix table name typo

### Priority 3: CODE QUALITY (Best Practices)
**Estimated Time: 4-5 hours**

1. Refactor navigation bar into template
2. Centralize error handling
3. Add input validation class
4. Improve code comments

### Priority 4: TESTING & DOCUMENTATION
**Estimated Time: 5-6 hours**

1. Create test cases document
2. Write deployment guide
3. Add code documentation
4. Create database initialization script

---

## PHASE 3: DETAILED FIXES & CODE EXAMPLES

### FIX #1: SQL INJECTION - Prepared Statements

#### BEFORE (VULNERABLE):
```php
$username=$_POST['username'];
$password=$_POST['password'];
$query="SELECT * FROM admin WHERE username='$username' AND password='$password'";
$result=mysqli_query($conn, $query);
```

#### AFTER (SECURE):
```php
$username=$_POST['username'];
$password=$_POST['password'];

// Use prepared statement
$query = "SELECT * FROM admin WHERE username=? AND password=?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "ss", $username, $password);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if(mysqli_num_rows($result)==1){
    $_SESSION['admin_id'] = $username;
    header("Location:dashboard.php");
}
else{
    $error = "Invalid Login";
}
```

---

### FIX #2: SESSION MANAGEMENT

#### Create: admin/session_check.php
```php
<?php
session_start();

// Check if user is logged in
if(!isset($_SESSION['admin_id'])){
    header("Location: ../admin/login.php");
    exit();
}
?>
```

#### Update: Every protected page (start of file)
```php
<?php
require_once("../admin/session_check.php");
require_once("../config/config.php");
?>
```

#### Update: admin/login.php
```php
<?php
session_start();
include "../config/config.php";

if(isset($_POST['login'])){
    $username=$_POST['username'];
    $password=$_POST['password'];
    
    // Use prepared statement (see FIX #1)
    // After successful verification:
    $_SESSION['admin_id'] = $username;
    header("Location:dashboard.php");
}
?>
```

#### Update: admin/logout.php
```php
<?php
session_start();
session_destroy();
header("Location: login.php");
?>
```

---

### FIX #3: INPUT VALIDATION

#### Create: helpers/validation.php
```php
<?php

class InputValidator {
    
    public static function validateName($name) {
        if(empty(trim($name))) {
            return false;
        }
        if(strlen($name) > 100) {
            return false;
        }
        if(!preg_match("/^[a-zA-Z\s]+$/", $name)) {
            return false; // Only letters and spaces
        }
        return true;
    }
    
    public static function validateAge($age) {
        if(!is_numeric($age)) {
            return false;
        }
        if($age < 18 || $age > 100) {
            return false;
        }
        return true;
    }
    
    public static function validatePhone($phone) {
        if(strlen($phone) < 10 || strlen($phone) > 15) {
            return false;
        }
        if(!preg_match("/^[0-9]{10,15}$/", $phone)) {
            return false;
        }
        return true;
    }
    
    public static function validateBloodGroup($blood_group) {
        $valid_groups = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];
        return in_array($blood_group, $valid_groups);
    }
    
    public static function validateQuantity($quantity) {
        if(!is_numeric($quantity) || $quantity <= 0) {
            return false;
        }
        return true;
    }
}

?>
```

#### Update: donor/add_donor.php (using validation)
```php
<?php
require_once("../admin/session_check.php");
include "../config/config.php";
require_once("../helpers/validation.php");

if(isset($_POST['submit'])){
    $name = trim($_POST['name']);
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $blood_group = $_POST['blood_group'];
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    
    // Validate all inputs
    if(!InputValidator::validateName($name)) {
        $error = "Invalid name. Only letters allowed.";
    }
    elseif(!InputValidator::validateAge($age)) {
        $error = "Age must be between 18 and 100.";
    }
    elseif(!InputValidator::validatePhone($phone)) {
        $error = "Invalid phone number (10-15 digits).";
    }
    elseif(!InputValidator::validateBloodGroup($blood_group)) {
        $error = "Invalid blood group selected.";
    }
    else {
        // Prepared statement
        $query = "INSERT INTO donor(name,age,gender,blood_group,phone,address) VALUES(?,?,?,?,?,?)";
        $stmt = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt, "sisisss", $name, $age, $gender, $blood_group, $phone, $address);
        
        if(mysqli_stmt_execute($stmt)) {
            $success = "Donor added successfully";
        }
        else {
            $error = "Database error: " . mysqli_error($conn);
        }
    }
}
?>
```

---

### FIX #4: PASSWORD HASHING

#### Create: helpers/auth.php
```php
<?php

class Auth {
    
    // Hash password (use bcrypt in production)
    public static function hashPassword($password) {
        return hash('sha256', $password);
    }
    
    // Verify password
    public static function verifyPassword($inputPassword, $hashedPassword) {
        return hash('sha256', $inputPassword) === $hashedPassword;
    }
}

?>
```

#### Update: admin/login.php
```php
<?php
session_start();
include "../config/config.php";
require_once("../helpers/auth.php");

if(isset($_POST['login'])){
    $username=$_POST['username'];
    $password=$_POST['password'];
    
    $query = "SELECT * FROM admin WHERE username=?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if(mysqli_num_rows($result)==1){
        $admin = mysqli_fetch_assoc($result);
        
        if(Auth::verifyPassword($password, $admin['password'])){
            $_SESSION['admin_id'] = $admin['admin_id'];
            $_SESSION['admin_name'] = $admin['name'];
            header("Location:dashboard.php");
        }
        else{
            $error = "Invalid password";
        }
    }
    else{
        $error = "Admin not found";
    }
}
?>
```

---

### FIX #5: TEMPLATE REFACTORING (DRY Principle)

#### Create: templates/navbar.php
```php
<?php
// Navigation bar component
?>

<style>
.navbar {
    background-color: #003366;
    padding: 15px 20px;
    margin-bottom: 20px;
}

.navbar a {
    color: white;
    text-decoration: none;
    margin-right: 15px;
    padding: 8px 12px;
    display: inline-block;
    border-radius: 4px;
    font-size: 14px;
}

.navbar a:hover {
    background-color: #005599;
}

.navbar a.logout {
    color: #ff6666;
    float: right;
}
</style>

<nav class="navbar">
    <a href="../admin/dashboard.php">📊 Dashboard</a>
    <a href="../donor/add_donor.php">➕ Add Donor</a>
    <a href="../donor/view_donor.php">👥 View Donors</a>
    <a href="../patient/add_patient.php">➕ Add Patient</a>
    <a href="../patient/view_patient.php">👥 View Patients</a>
    <a href="../blood_donation/add_donation.php">🩸 Add Donation</a>
    <a href="../blood_donation/view_donation.php">📋 View Donations</a>
    <a href="../blood_request/add_request.php">🏥 Add Request</a>
    <a href="../blood_request/view_request.php">📋 View Requests</a>
    <a href="../blood_inventory/view_inventory.php">📦 Inventory</a>
    <a href="../admin/logout.php" class="logout">🚪 Logout</a>
</nav>
```

#### Update: Any file using navbar
```php
<?php
require_once("../admin/session_check.php");
require_once("../config/config.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blood Bank - View Donors</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 0; }
        table { border-collapse: collapse; width: 90%; margin: 20px auto; }
        th, td { padding: 12px; text-align: center; border: 1px solid #ddd; }
        th { background-color: #003366; color: white; }
        tr:nth-child(even) { background-color: #f9f9f9; }
    </style>
</head>
<body>

<?php include "../templates/navbar.php"; ?>

<h2>Donor List</h2>

<table>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Age</th>
        <th>Gender</th>
        <th>Blood Group</th>
        <th>Phone</th>
        <th>Actions</th>
    </tr>
    
    <?php
    $result = mysqli_query($conn,"SELECT * FROM donor");
    
    while($row = mysqli_fetch_assoc($result)){
        echo "
        <tr>
            <td>{$row['donor_id']}</td>
            <td>{$row['name']}</td>
            <td>{$row['age']}</td>
            <td>{$row['gender']}</td>
            <td>{$row['blood_group']}</td>
            <td>{$row['phone']}</td>
            <td>
                <a href='edit_donor.php?id={$row['donor_id']}'>Edit</a> | 
                <a href='delete_donor.php?id={$row['donor_id']}'>Delete</a>
            </td>
        </tr>
        ";
    }
    ?>
</table>

<br><br>
<a href="../admin/dashboard.php">← Back to Dashboard</a>

</body>
</html>
```

---

### FIX #6: ADD UPDATE OPERATIONS

#### Create: donor/edit_donor.php
```php
<?php
require_once("../admin/session_check.php");
include "../config/config.php";
require_once("../helpers/validation.php");

$donor_id = $_GET['id'] ?? null;

if(!$donor_id) {
    header("Location: view_donor.php");
    exit();
}

// Fetch current donor data
$query = "SELECT * FROM donor WHERE donor_id=?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $donor_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$donor = mysqli_fetch_assoc($result);

if(!$donor) {
    $error = "Donor not found";
}

if(isset($_POST['submit'])){
    $name = trim($_POST['name']);
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $blood_group = $_POST['blood_group'];
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    
    // Validate
    if(!InputValidator::validateName($name)) {
        $error = "Invalid name";
    }
    elseif(!InputValidator::validateAge($age)) {
        $error = "Invalid age";
    }
    elseif(!InputValidator::validatePhone($phone)) {
        $error = "Invalid phone";
    }
    else {
        $query = "UPDATE donor SET name=?, age=?, gender=?, blood_group=?, phone=?, address=? WHERE donor_id=?";
        $stmt = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt, "sisissi", $name, $age, $gender, $blood_group, $phone, $address, $donor_id);
        
        if(mysqli_stmt_execute($stmt)) {
            $success = "Donor updated successfully";
            // Refresh donor data
            $_POST = [];
            $result = mysqli_query($conn, "SELECT * FROM donor WHERE donor_id='$donor_id'");
            $donor = mysqli_fetch_assoc($result);
        }
        else {
            $error = "Database error: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Donor</title>
</head>
<body>

<?php include "../templates/navbar.php"; ?>

<h2>Edit Donor</h2>

<?php if(isset($error)): ?>
    <div style="color: red; padding: 10px; background: #ffe6e6;">
        <?php echo htmlspecialchars($error); ?>
    </div>
<?php endif; ?>

<?php if(isset($success)): ?>
    <div style="color: green; padding: 10px; background: #e6ffe6;">
        <?php echo htmlspecialchars($success); ?>
    </div>
<?php endif; ?>

<?php if(!isset($error) || isset($donor)): ?>
<form method="POST">
    Name:<br>
    <input type="text" name="name" value="<?php echo htmlspecialchars($donor['name'] ?? ''); ?>" required><br><br>
    
    Age:<br>
    <input type="number" name="age" value="<?php echo htmlspecialchars($donor['age'] ?? ''); ?>" required><br><br>
    
    Gender:<br>
    <select name="gender">
        <option value="Male" <?php if(($donor['gender'] ?? '') == 'Male') echo 'selected'; ?>>Male</option>
        <option value="Female" <?php if(($donor['gender'] ?? '') == 'Female') echo 'selected'; ?>>Female</option>
    </select><br><br>
    
    Blood Group:<br>
    <select name="blood_group">
        <?php
        $blood_groups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
        foreach($blood_groups as $bg):
        ?>
            <option value="<?php echo $bg; ?>" <?php if(($donor['blood_group'] ?? '') == $bg) echo 'selected'; ?>>
                <?php echo $bg; ?>
            </option>
        <?php endforeach; ?>
    </select><br><br>
    
    Phone:<br>
    <input type="text" name="phone" value="<?php echo htmlspecialchars($donor['phone'] ?? ''); ?>" required><br><br>
    
    Address:<br>
    <textarea name="address"><?php echo htmlspecialchars($donor['address'] ?? ''); ?></textarea><br><br>
    
    <button name="submit">Update Donor</button>
    <button type="button" onclick="window.location.href='view_donor.php'">Cancel</button>
</form>
<?php endif; ?>

</body>
</html>
```

---

### FIX #7: FIX TABLE NAME TYPO

#### Database Correction Script
```sql
-- This needs to be run once

-- Option 1: If table already created with typo
RENAME TABLE blood_donotion TO blood_donation;

-- Option 2: Create correct table (if starting fresh)
CREATE TABLE IF NOT EXISTS blood_donation (
    donation_id INT AUTO_INCREMENT PRIMARY KEY,
    donor_id INT NOT NULL,
    blood_group VARCHAR(5) NOT NULL,
    donation_date DATE NOT NULL,
    quantity INT NOT NULL,
    FOREIGN KEY (donor_id) REFERENCES donor(donor_id)
);
```

#### Update all PHP files:
- `blood_donation/add_donation.php` - Change "blood_donotion" to "blood_donation"
- `blood_donation/view_donation.php` - Change "blood_donotion" to "blood_donation"

---

### FIX #8: ERROR HANDLING & SUCCESS FEEDBACK

#### Create: helpers/database.php
```php
<?php

class Database {
    
    public static function executeQuery($conn, $query, $types = "", $params = []) {
        try {
            if($types !== "" && !empty($params)) {
                $stmt = mysqli_prepare($conn, $query);
                if(!$stmt) {
                    throw new Exception("Query prepare failed: " . mysqli_error($conn));
                }
                
                $bind_params = array_merge([$stmt, $types], $params);
                if(!call_user_func_array('mysqli_stmt_bind_param', $bind_params)) {
                    throw new Exception("Bind params failed: " . mysqli_error($conn));
                }
                
                if(!mysqli_stmt_execute($stmt)) {
                    throw new Exception("Execute failed: " . mysqli_error($conn));
                }
                
                return mysqli_stmt_get_result($stmt);
            }
            else {
                $result = mysqli_query($conn, $query);
                if(!$result) {
                    throw new Exception("Query failed: " . mysqli_error($conn));
                }
                return $result;
            }
        }
        catch(Exception $e) {
            // Log error (in production, log to file, not display)
            error_log($e->getMessage());
            return false;
        }
    }
}

?>
```

---

## PHASE 4: NEW FOLDER STRUCTURE (RECOMMENDED)

```
bloodbank/
│
├── config/
│   └── config.php                    # Database connection
│
├── admin/
│   ├── login.php
│   ├── dashboard.php
│   ├── logout.php
│   └── session_check.php            # NEW: Session verification
│
├── donor/
│   ├── add_donor.php
│   ├── view_donor.php
│   ├── edit_donor.php               # NEW
│   ├── delete_donor.php
│   └── search_donor.php             # NEW
│
├── patient/
│   ├── add_patient.php
│   ├── view_patient.php
│   ├── edit_patient.php             # NEW
│   └── delete_patient.php
│
├── blood_donation/
│   ├── add_donation.php
│   ├── view_donation.php
│   └── donation_history.php         # NEW
│
├── blood_request/
│   ├── add_request.php
│   ├── view_request.php
│   ├── approve_request.php
│   └── reject_request.php
│
├── blood_inventory/
│   ├── view_inventory.php
│   ├── low_stock_alerts.php         # NEW
│   └── inventory_report.php         # NEW
│
├── helpers/                          # NEW FOLDER
│   ├── validation.php
│   ├── auth.php
│   ├── database.php
│   └── error_handler.php
│
├── templates/                        # NEW FOLDER
│   ├── navbar.php
│   ├── header.php
│   ├── footer.php
│   └── messages.php                 # For success/error display
│
├── css/                              # NEW FOLDER (if using)
│   └── style.css
│
├── database/                         # NEW FOLDER
│   ├── schema.sql                   # CREATE TABLE statements
│   ├── sample_data.sql              # Sample data for testing
│   └── backup.sql                   # For backups
│
├── tests/                            # NEW FOLDER
│   ├── test_cases.md
│   ├── test_data.sql
│   └── test_results.txt
│
├── docs/                             # NEW FOLDER
│   ├── DEPLOYMENT.md
│   ├── TROUBLESHOOTING.md
│   ├── API_DOCUMENTATION.md
│   └── ARCHITECTURE.md
│
├── .gitignore                        # NEW: For version control
├── README.md                         # Updated
└── index.php
```

---

## PHASE 5: IMPLEMENTATION CHECKLIST

### Week 1: Security Fixes
- [ ] Fix SQL injection (prepared statements)
- [ ] Implement session management
- [ ] Add password hashing
- [ ] Add input validation

### Week 2: Missing Features
- [ ] Add UPDATE operations (donor, patient)
- [ ] Implement low stock alerts
- [ ] Add search functionality
- [ ] Fix table name typo

### Week 3: Code Quality
- [ ] Create navbar template
- [ ] Create error handling class
- [ ] Add code comments
- [ ] Fix styling consistency

### Week 4: Testing & Documentation
- [ ] Write test cases
- [ ] Create deployment guide
- [ ] Write troubleshooting guide
- [ ] Create database initialization script

---

## PHASE 6: TESTING STRATEGY

### Unit Tests (Example)

#### Test File: tests/test_validation.php
```php
<?php
require_once("../helpers/validation.php");

class ValidationTests {
    
    public function testValidateName() {
        // Test 1: Valid name
        $result = InputValidator::validateName("John Doe");
        assert($result === true, "Valid name should pass");
        
        // Test 2: Name with numbers
        $result = InputValidator::validateName("John123");
        assert($result === false, "Name with numbers should fail");
        
        // Test 3: Empty name
        $result = InputValidator::validateName("");
        assert($result === false, "Empty name should fail");
        
        echo "✓ validateName tests passed\n";
    }
    
    public function testValidateAge() {
        // Test 1: Valid age
        $result = InputValidator::validateAge(25);
        assert($result === true, "Age 25 should pass");
        
        // Test 2: Age below 18
        $result = InputValidator::validateAge(15);
        assert($result === false, "Age below 18 should fail");
        
        // Test 3: Non-numeric age
        $result = InputValidator::validateAge("abc");
        assert($result === false, "Non-numeric age should fail");
        
        echo "✓ validateAge tests passed\n";
    }
}

// Run tests
$tests = new ValidationTests();
$tests->testValidateName();
$tests->testValidateAge();
echo "\n✅ All tests passed!\n";
?>
```

### Functional Tests

#### Test Cases Document: tests/test_cases.md
```markdown
# Test Cases for BBMS

## Test Case 1: Admin Login
**Objective:** Verify admin can login with correct credentials
**Steps:**
1. Navigate to admin/login.php
2. Enter username: admin
3. Enter password: password123
4. Click Login

**Expected Result:** Redirected to dashboard.php with session set

**Actual Result:** ___________

---

## Test Case 2: Add Donor with Invalid Age
**Objective:** Verify validation rejects invalid age

**Steps:**
1. Navigate to donor/add_donor.php
2. Enter name: John Doe
3. Enter age: 15 (below 18)
4. Enter blood group: A+
5. Click Add

**Expected Result:** Error message: "Age must be between 18 and 100"

**Actual Result:** ___________

---

(Create similar test cases for all features)
```

---

## PHASE 7: DEPLOYMENT CHECKLIST

### Before Deployment

- [ ] All security vulnerabilities fixed
- [ ] Database backup created
- [ ] All CRUD operations tested
- [ ] Error handling implemented
- [ ] Input validation on all forms
- [ ] Session management verified
- [ ] Passwords hashed
- [ ] .gitignore created (exclude config.php, database files)

### Deployment Steps (Local/Hosting)

```bash
# 1. Create database
mysql -u root -p < database/schema.sql

# 2. Insert sample data
mysql -u root -p bloodbank_db < database/sample_data.sql

# 3. Update config.php with correct credentials
# Edit: config/config.php with your database credentials

# 4. Create .htaccess (optional, for URL rewriting)
# .htaccess content:
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ index.php?path=$1 [QSA,L]

# 5. Set proper file permissions
chmod 755 /var/www/html/bloodbank
chmod 644 /var/www/html/bloodbank/*.php
chmod 700 database/  # Keep database folder private

# 6. Test in browser
# Navigate to: http://localhost/bloodbank/
```

---

## PHASE 8: EXAMPLE - COMPLETE REFACTORED FILE

### Complete: donor/view_donor.php (AFTER IMPROVEMENTS)

```php
<?php
/**
 * Blood Bank Management System - View Donors Page
 * 
 * Purpose: Display all registered donors with edit/delete options
 * Author: BBMS Team
 * Version: 2.0
 */

require_once("../admin/session_check.php");
require_once("../config/config.php");
require_once("../helpers/database.php");

// Get search query if provided
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Prepare query
if($search) {
    $query = "SELECT * FROM donor WHERE name LIKE ? OR phone LIKE ? ORDER BY donor_id DESC";
    $stmt = mysqli_prepare($conn, $query);
    $search_param = "%$search%";
    mysqli_stmt_bind_param($stmt, "ss", $search_param, $search_param);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
}
else {
    $result = Database::executeQuery($conn, "SELECT * FROM donor ORDER BY donor_id DESC");
}

if(!$result) {
    $error = "Failed to fetch donors. Please try again.";
}

$donors = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blood Bank - View Donors</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            color: #333;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            margin-bottom: 20px;
        }
        
        .header h2 {
            color: #003366;
            margin-bottom: 10px;
        }
        
        .search-bar {
            margin-bottom: 20px;
            display: flex;
            gap: 10px;
        }
        
        .search-bar input {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 300px;
        }
        
        .search-bar button {
            padding: 10px 20px;
            background-color: #003366;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        th {
            background-color: #003366;
            color: white;
            padding: 12px;
            text-align: left;
            font-weight: 600;
        }
        
        td {
            padding: 12px;
            border-bottom: 1px solid #eee;
        }
        
        tr:hover {
            background-color: #f9f9f9;
        }
        
        .actions {
            display: flex;
            gap: 8px;
        }
        
        .btn {
            padding: 6px 12px;
            text-decoration: none;
            border-radius: 4px;
            font-size: 14px;
            border: none;
            cursor: pointer;
        }
        
        .btn-edit {
            background-color: #4CAF50;
            color: white;
        }
        
        .btn-delete {
            background-color: #f44336;
            color: white;
        }
        
        .btn:hover {
            opacity: 0.8;
        }
        
        .error {
            background-color: #ffe6e6;
            color: #d32f2f;
            padding: 12px;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        
        .empty-message {
            text-align: center;
            padding: 40px;
            color: #666;
        }
    </style>
</head>
<body>

<?php include "../templates/navbar.php"; ?>

<div class="container">
    <div class="header">
        <h2>📋 Donor List</h2>
        <p>Total Donors: <strong><?php echo count($donors); ?></strong></p>
    </div>
    
    <?php if(isset($error)): ?>
        <div class="error">⚠️ <?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    
    <div class="search-bar">
        <form method="GET" style="display: flex; gap: 10px;">
            <input type="text" name="search" placeholder="Search by name or phone..." 
                   value="<?php echo htmlspecialchars($search); ?>">
            <button type="submit">🔍 Search</button>
            <a href="view_donor.php" class="btn" style="background-color: #999;">Clear</a>
        </form>
    </div>
    
    <?php if(count($donors) > 0): ?>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Age</th>
                <th>Gender</th>
                <th>Blood Group</th>
                <th>Phone</th>
                <th>Address</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($donors as $donor): ?>
            <tr>
                <td><?php echo htmlspecialchars($donor['donor_id']); ?></td>
                <td><?php echo htmlspecialchars($donor['name']); ?></td>
                <td><?php echo htmlspecialchars($donor['age']); ?></td>
                <td><?php echo htmlspecialchars($donor['gender']); ?></td>
                <td><strong><?php echo htmlspecialchars($donor['blood_group']); ?></strong></td>
                <td><?php echo htmlspecialchars($donor['phone']); ?></td>
                <td><?php echo htmlspecialchars($donor['address']); ?></td>
                <td>
                    <div class="actions">
                        <a href="edit_donor.php?id=<?php echo $donor['donor_id']; ?>" class="btn btn-edit">✏️ Edit</a>
                        <a href="delete_donor.php?id=<?php echo $donor['donor_id']; ?>" class="btn btn-delete" 
                           onclick="return confirm('Are you sure?');">🗑️ Delete</a>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    
    <?php else: ?>
    <div class="empty-message">
        <p>No donors found.</p>
        <p><a href="add_donor.php">Add a new donor</a></p>
    </div>
    <?php endif; ?>
    
    <br><br>
    <a href="../admin/dashboard.php" class="btn" style="background-color: #666;">← Back to Dashboard</a>
</div>

</body>
</html>
```

---

## PHASE 9: NEXT STEPS SUMMARY

### Immediate Actions (This Week)

1. **Create Security Fixes Priority List**
   - [ ] Implement prepared statements in all files
   - [ ] Add session_check.php
   - [ ] Create validation.php and auth.php
   - [ ] Create templates/navbar.php

2. **Update 5 Core Files First**
   - admin/login.php
   - donor/view_donor.php
   - donor/add_donor.php
   - blood_donation/add_donation.php
   - blood_request/add_request.php

3. **Test After Each Fix**
   - Try to login
   - Try to add a donor
   - Verify error messages work

### Short Term (Next 2 Weeks)

- Add UPDATE operations (edit pages)
- Implement search functionality
- Fix all table name typos
- Create error handling class
- Refactor all navigation bars

### Medium Term (Month 1)

- Create comprehensive test cases
- Write deployment guide
- Add code documentation
- Implement low stock alerts
- Create database initialization script

### Documentation to Create

1. **DEPLOYMENT.md** - How to set up locally/on server
2. **TROUBLESHOOTING.md** - Common issues and fixes
3. **TESTING.md** - Test cases and how to run them
4. **ARCHITECTURE.md** - System design overview
5. **API_DOCUMENTATION.md** - Database schema details

---

## CONCLUSION

Your BBMS has a **solid conceptual foundation** but needs **immediate security hardening** and **feature completion**. Follow this guide phase by phase, and you'll have a professional-grade software engineering project ready for submission.

**Estimated Total Time: 20-25 hours**

- Security Fixes: 4-6 hours (PRIORITY!)
- Missing Features: 6-8 hours
- Code Quality: 4-5 hours
- Testing & Docs: 5-6 hours

---

## Questions to Ask Yourself

1. ✅ Are all database queries using prepared statements?
2. ✅ Is the user logged in before accessing any protected page?
3. ✅ Are passwords hashed, not plain text?
4. ✅ Is user input validated before insertion?
5. ✅ Are error messages displayed to users safely?
6. ✅ Is code DRY (Don't Repeat Yourself) - no duplication?
7. ✅ Can every feature from the SRS be demonstrated?
8. ✅ Do you have test cases documenting what you tested?

---

**Good luck with your project! 🚀**

