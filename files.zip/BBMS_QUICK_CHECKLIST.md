# BBMS Project - Quick Implementation Checklist

## 🚨 CRITICAL FIXES (Do These FIRST!)

### Week 1: Security Hardening

#### 1. SQL Injection Fix
- [ ] Update `admin/login.php` with prepared statements
- [ ] Update `donor/add_donor.php` with prepared statements  
- [ ] Update `patient/add_patient.php` with prepared statements
- [ ] Update `blood_donation/add_donation.php` with prepared statements
- [ ] Update `blood_request/add_request.php` with prepared statements
- [ ] Update `blood_request/approve_request.php` with prepared statements
- [ ] Update `blood_request/reject_request.php` with prepared statements

**Template to use:**
```php
// BEFORE (UNSAFE)
$query = "SELECT * FROM donor WHERE id='$id'";
mysqli_query($conn, $query);

// AFTER (SAFE)
$query = "SELECT * FROM donor WHERE id=?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
```

---

#### 2. Session Management Setup
- [ ] Create `admin/session_check.php` (copy from guide)
- [ ] Add `session_start()` to `admin/login.php`
- [ ] Add `session_start()` to `admin/logout.php`
- [ ] Add `require_once("../admin/session_check.php")` to ALL protected pages:
  - [ ] donor/add_donor.php
  - [ ] donor/view_donor.php
  - [ ] donor/delete_donor.php
  - [ ] patient/add_patient.php
  - [ ] patient/view_patient.php
  - [ ] patient/delete_patient.php
  - [ ] blood_donation/add_donation.php
  - [ ] blood_donation/view_donation.php
  - [ ] blood_request/add_request.php
  - [ ] blood_request/view_request.php
  - [ ] blood_request/approve_request.php
  - [ ] blood_request/reject_request.php
  - [ ] blood_inventory/view_inventory.php

---

#### 3. Input Validation Setup
- [ ] Create `helpers/validation.php` (copy from guide)
- [ ] Create `helpers/auth.php` (copy from guide)
- [ ] Create `helpers/database.php` (copy from guide)

**Apply to these files:**
- [ ] donor/add_donor.php - validate: name, age, phone, blood_group
- [ ] donor/edit_donor.php - same validations (after creating edit file)
- [ ] patient/add_patient.php - same validations
- [ ] patient/edit_patient.php - same validations (after creating edit file)
- [ ] blood_donation/add_donation.php - validate: quantity, blood_group
- [ ] blood_request/add_request.php - validate: quantity, blood_group

---

#### 4. Password Hashing
- [ ] Update `admin/login.php` to use `Auth::hashPassword()` from helpers/auth.php
- [ ] Hash all existing admin passwords in database:
  ```sql
  UPDATE admin SET password = SHA2(password, 256);
  ```
- [ ] When creating new admin accounts, hash password before insert

---

## 🆕 MISSING FEATURES (Week 2)

### Add UPDATE Operations
- [ ] Create `donor/edit_donor.php` (template in guide)
- [ ] Create `patient/edit_patient.php` (similar to donor edit)
- [ ] Update `donor/view_donor.php` to add "Edit" link
- [ ] Update `patient/view_patient.php` to add "Edit" link

---

### Fix Database Issues
- [ ] Rename table: `blood_donotion` → `blood_donation`
  ```sql
  RENAME TABLE blood_donotion TO blood_donation;
  ```
- [ ] Update all PHP files that reference this table:
  - [ ] blood_donation/add_donation.php
  - [ ] blood_donation/view_donation.php

---

### Add Search Functionality
- [ ] Add search to `donor/view_donor.php`
- [ ] Add search to `patient/view_patient.php`
- [ ] Add search to `blood_donation/view_donation.php`
- [ ] Add search to `blood_request/view_request.php`

---

### Add Alerts & Reports
- [ ] Create `blood_inventory/low_stock_alerts.php` (show stock < 10 units)
- [ ] Create `blood_inventory/inventory_report.php` (summary report)

---

## 🎨 CODE QUALITY (Week 3)

### Template Refactoring
- [ ] Create `templates/navbar.php` (copy from guide)
- [ ] Create `templates/header.php` for common HTML head
- [ ] Create `templates/footer.php` for footer content
- [ ] Update all files to include navbar instead of inline HTML

**Replace this pattern:**
```php
// OLD: Navbar duplicated in every file
<div style="background:blue;padding:20px;">
  <a href="../admin/dashboard.php">Dashboard</a>
  ...
</div>

// NEW: One line
<?php include "../templates/navbar.php"; ?>
```

---

### Consistency Improvements
- [ ] Standardize all database includes to use `require_once`
- [ ] Standardize all table borders/styling
- [ ] Add comments explaining logic in complex functions
- [ ] Use consistent error message display

**Example comment to add:**
```php
/**
 * Donor Management - Add New Donor
 * 
 * This page handles:
 * 1. Display add donor form
 * 2. Validate user input
 * 3. Insert into database
 * 4. Display success/error message
 */
```

---

### Error Handling
- [ ] Add error display message HTML template
- [ ] Use consistent error/success message styling
- [ ] Check all database queries for failures
- [ ] Don't show raw SQL errors to users

---

## 📝 TESTING & DOCUMENTATION (Week 4)

### Test Case Documentation
- [ ] Create `tests/test_cases.md` with all test cases
- [ ] Document test data needed
- [ ] Create `tests/test_data.sql` with sample data for testing

**Test cases to document:**
- [ ] Admin login with valid credentials
- [ ] Admin login with invalid credentials
- [ ] Add donor with valid data
- [ ] Add donor with invalid age
- [ ] Add donor with invalid phone
- [ ] Edit donor successfully
- [ ] Delete donor (with confirmation)
- [ ] Add blood donation and verify inventory update
- [ ] Request blood successfully
- [ ] Approve blood request with sufficient stock
- [ ] Reject blood request if stock insufficient
- [ ] View donors with search filter

---

### Database Initialization
- [ ] Create `database/schema.sql` with all CREATE TABLE statements
- [ ] Create `database/sample_data.sql` with test data
- [ ] Create `database/backup.sql` as backup template

---

### Deployment Documentation
- [ ] Create `docs/DEPLOYMENT.md` with steps to deploy
- [ ] Create `docs/TROUBLESHOOTING.md` with common issues
- [ ] Create `docs/ARCHITECTURE.md` describing system design
- [ ] Create `docs/README_DEVELOPER.md` for developers

---

## 📁 FOLDER STRUCTURE TO CREATE

```
bloodbank/
├── helpers/                    ← CREATE THIS FOLDER
│   ├── validation.php
│   ├── auth.php
│   ├── database.php
│   └── error_handler.php
│
├── templates/                  ← CREATE THIS FOLDER
│   ├── navbar.php
│   ├── header.php
│   ├── footer.php
│   └── messages.php
│
├── database/                   ← CREATE THIS FOLDER
│   ├── schema.sql
│   ├── sample_data.sql
│   └── backup.sql
│
├── docs/                       ← CREATE THIS FOLDER
│   ├── DEPLOYMENT.md
│   ├── TROUBLESHOOTING.md
│   ├── ARCHITECTURE.md
│   └── README_DEVELOPER.md
│
└── tests/                      ← CREATE THIS FOLDER
    ├── test_cases.md
    ├── test_data.sql
    └── test_results.txt
```

---

## ✅ FILE-BY-FILE FIXES (Priority Order)

### 1️⃣ admin/login.php (CRITICAL)
- [ ] Use prepared statements
- [ ] Implement session creation
- [ ] Hash password verification
- [ ] Add error messages

**Lines to change:**
```php
// Line ~9: Add session start
session_start();

// Line ~14-15: Use prepared statement
$query = "SELECT * FROM admin WHERE username=?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "s", $username);

// Line ~17: Get result properly
$result = mysqli_stmt_get_result($stmt);
```

---

### 2️⃣ admin/session_check.php (NEW FILE)
Copy from main guide - create new file

---

### 3️⃣ helpers/ folder (NEW FILES)
Create all 4 helper files from main guide

---

### 4️⃣ templates/navbar.php (NEW FILE)
Create from main guide

---

### 5️⃣ donor/add_donor.php
- [ ] Add session check
- [ ] Add input validation
- [ ] Use prepared statements
- [ ] Add error handling
- [ ] Include navbar template

**Template from main guide available**

---

### 6️⃣ donor/view_donor.php
- [ ] Add session check
- [ ] Include navbar template
- [ ] Add search functionality
- [ ] Add "Edit" link for each row
- [ ] Use proper table styling

---

### 7️⃣ donor/edit_donor.php (NEW FILE)
Copy from main guide

---

### 8️⃣ blood_donation/add_donation.php
- [ ] Add session check
- [ ] Fix table name: blood_donotion → blood_donation
- [ ] Use prepared statements
- [ ] Add validation for quantity
- [ ] Include navbar template

---

### 9️⃣ blood_donation/view_donation.php
- [ ] Add session check
- [ ] Fix table name: blood_donotion → blood_donation
- [ ] Include navbar template
- [ ] Add search functionality

---

### 🔟 blood_request/add_request.php
- [ ] Add session check
- [ ] Use prepared statements
- [ ] Add validation
- [ ] Include navbar template
- [ ] Remove duplicate DOCTYPE

---

### All Other Files
Apply the same pattern:
1. Add session check
2. Include navbar template
3. Use prepared statements
4. Add input validation
5. Proper error handling

---

## 🧪 TESTING WORKFLOW

### After Each Fix:
```
1. Test in browser
2. Check browser console for errors
3. Check PHP error logs
4. Verify database changes
5. Test edge cases (empty input, invalid data, etc.)
```

---

## 📊 PROGRESS TRACKER

### Week 1 (Security)
- [ ] SQL Injection fixed in 7 files
- [ ] Session management implemented
- [ ] Input validation created
- [ ] Password hashing implemented
- **Target: 0 SQL injection vulnerabilities**

### Week 2 (Features)
- [ ] Edit donor/patient pages created
- [ ] Table name typo fixed
- [ ] Search functionality added
- [ ] Low stock alerts created
- **Target: All CRUD operations complete**

### Week 3 (Quality)
- [ ] Templates refactored (80% code duplication removed)
- [ ] Error handling standardized
- [ ] Code comments added
- [ ] Styling consistent
- **Target: Professional, maintainable code**

### Week 4 (Documentation)
- [ ] Test cases documented (15+ test cases)
- [ ] Deployment guide written
- [ ] Database schema documented
- [ ] Architecture documented
- **Target: Ready for submission**

---

## 💡 TIPS & COMMON MISTAKES

### ✅ DO:
- Test after every change
- Use prepared statements for ALL database queries
- Validate ALL user input
- Check if user is logged in on protected pages
- Hash passwords
- Use htmlspecialchars() when displaying user input
- Comment complex logic
- Keep folder structure organized

### ❌ DON'T:
- Mix HTML and PHP logic (keep them separate)
- Use mysqli_query() with concatenated strings
- Trust user input
- Store passwords in plain text
- Display raw SQL errors to users
- Duplicate code (use templates/includes)
- Commit config.php to GitHub (use .gitignore)
- Store database backup in web root

---

## 🚀 GO-LIVE CHECKLIST

Before submitting project:

- [ ] All security vulnerabilities fixed
- [ ] No SQL injection possible
- [ ] Session management working
- [ ] All CRUD operations tested
- [ ] No code duplication (DRY principle)
- [ ] Error handling in place
- [ ] Database backup created
- [ ] Deployment guide written
- [ ] Test cases documented
- [ ] Code comments added
- [ ] Folder structure organized
- [ ] All files follow naming convention
- [ ] .gitignore created
- [ ] README.md updated
- [ ] No hardcoded passwords/credentials

---

## 📞 COMMON ERROR FIXES

### Error: "mysqli_fetch_assoc() expects parameter 1 to be mysqli_result"
**Cause:** Query failed (likely SQL syntax error)
**Fix:** Check query, verify table names, use error checking

### Error: "Headers already sent"
**Cause:** Output before header() call
**Fix:** Move header() calls before any echo/output

### Error: "Call to undefined function session_start()"
**Cause:** session_start() not called at top of file
**Fix:** Add `session_start();` as first line of PHP

### Error: "Undefined index"
**Cause:** Accessing $_POST/GET key that doesn't exist
**Fix:** Use `isset()` check first or null coalescing `$_POST['key'] ?? null`

---

## 📈 ESTIMATED TIMELINE

- **Total Time: 20-25 hours**
- Security Fixes: 4-6 hours
- Missing Features: 6-8 hours  
- Code Quality: 4-5 hours
- Testing & Docs: 5-6 hours

**Best approach: Spend 4-5 hours per day, 5 days = Complete in 1 week**

---

**Remember: Security first, features second, polish third!**

