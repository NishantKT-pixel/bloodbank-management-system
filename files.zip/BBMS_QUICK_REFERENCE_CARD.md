# BBMS Quick Reference Card
## Common Patterns & Code Snippets

---

## 1. PREPARED STATEMENTS (Most Important!)

### SELECT Query
```php
$query = "SELECT * FROM donor WHERE donor_id = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $donor_id);  // i=integer
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$row = mysqli_fetch_assoc($result);
```

### INSERT Query
```php
$query = "INSERT INTO donor(name, age, blood_group) VALUES(?, ?, ?)";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "sis", $name, $age, $blood_group);
// s=string, i=integer, s=string
mysqli_stmt_execute($stmt);
if(mysqli_stmt_affected_rows($stmt) > 0){
    echo "Inserted successfully";
}
```

### UPDATE Query
```php
$query = "UPDATE donor SET name=?, age=? WHERE donor_id=?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "sii", $name, $age, $donor_id);
mysqli_stmt_execute($stmt);
```

### DELETE Query
```php
$query = "DELETE FROM donor WHERE donor_id=?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $donor_id);
mysqli_stmt_execute($stmt);
```

### Type Codes
```
i = integer
s = string
d = decimal/float
b = blob (binary)
```

---

## 2. SESSION MANAGEMENT

### Start Session
```php
<?php
session_start();
?>
```

### Set Session Variable
```php
$_SESSION['admin_id'] = 1;
$_SESSION['admin_name'] = "John";
```

### Get Session Variable
```php
if(isset($_SESSION['admin_id'])){
    echo $_SESSION['admin_id'];
}
```

### Check if Logged In
```php
if(!isset($_SESSION['admin_id'])){
    header("Location: ../admin/login.php");
    exit();
}
```

### Logout
```php
session_start();
session_destroy();
header("Location: login.php");
```

---

## 3. INPUT HANDLING

### Get POST Data
```php
$name = $_POST['name'] ?? null;
// Or
if(isset($_POST['name'])){
    $name = $_POST['name'];
}
```

### Trim Whitespace
```php
$name = trim($_POST['name']);
```

### Sanitize Output (Prevent XSS)
```php
echo htmlspecialchars($name);
// OR
echo htmlspecialchars($_POST['name'], ENT_QUOTES, 'UTF-8');
```

### Check if Empty
```php
if(empty($name)){
    $error = "Name is required";
}
```

### Validate Email
```php
if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
    $error = "Invalid email";
}
```

---

## 4. FORM PATTERNS

### Simple Form
```php
<form method="POST" action="page.php">
    <input type="text" name="field1" required>
    <input type="email" name="field2" required>
    <button type="submit" name="submit">Submit</button>
</form>

<?php
if(isset($_POST['submit'])){
    $field1 = trim($_POST['field1']);
    $field2 = trim($_POST['field2']);
    // Process...
}
?>
```

### Form with Error Messages
```php
<?php
$error = null;
$success = null;

if(isset($_POST['submit'])){
    if(empty($name)){
        $error = "Name required";
    }
    else {
        // Save to database
        $success = "Saved successfully";
    }
}
?>

<?php if($error): ?>
    <div style="color: red;"><?php echo $error; ?></div>
<?php endif; ?>

<?php if($success): ?>
    <div style="color: green;"><?php echo $success; ?></div>
<?php endif; ?>

<form method="POST">
    <input name="name" value="<?php echo htmlspecialchars($name ?? ''); ?>">
    <button type="submit" name="submit">Submit</button>
</form>
```

---

## 5. VALIDATION PATTERNS

### Validate Name
```php
if(preg_match("/^[a-zA-Z\s]+$/", $name) && strlen($name) <= 100){
    // Valid
}
```

### Validate Age
```php
if(is_numeric($age) && $age >= 18 && $age <= 100){
    // Valid
}
```

### Validate Phone
```php
if(preg_match("/^[0-9]{10,15}$/", $phone)){
    // Valid
}
```

### Validate Blood Group
```php
$valid_groups = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];
if(in_array($blood_group, $valid_groups)){
    // Valid
}
```

### Validate Number (Positive)
```php
if(is_numeric($quantity) && $quantity > 0){
    // Valid
}
```

---

## 6. DATABASE PATTERNS

### Check if Record Exists
```php
$query = "SELECT id FROM donor WHERE id = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if(mysqli_num_rows($result) > 0){
    // Record exists
}
```

### Get All Records
```php
$result = mysqli_query($conn, "SELECT * FROM donor");
while($row = mysqli_fetch_assoc($result)){
    echo $row['name'];
}
```

### Get Count
```php
$result = mysqli_query($conn, "SELECT COUNT(*) as total FROM donor");
$row = mysqli_fetch_assoc($result);
echo $row['total'];
```

### Check Query Success
```php
if(!$result){
    echo "Error: " . mysqli_error($conn);
}
```

---

## 7. COMMON PATTERNS

### Check if Form Submitted
```php
// Method 1: Check button
if(isset($_POST['submit'])){ ... }

// Method 2: Check request method
if($_SERVER['REQUEST_METHOD'] === 'POST'){ ... }
```

### Redirect
```php
header("Location: page.php");
exit();
```

### Redirect with Parameter
```php
header("Location: page.php?id=5&status=success");
```

### Set Error and Stay on Page
```php
$error = "Something went wrong";
// Don't redirect, page will show error
```

### Confirm Before Delete
```php
<a href="delete.php?id=<?php echo $id; ?>" 
   onclick="return confirm('Are you sure?');">
    Delete
</a>
```

---

## 8. INCLUDE/REQUIRE PATTERNS

### Include at Top (Session Check)
```php
<?php
require_once("../admin/session_check.php");
require_once("../config/config.php");
require_once("../helpers/validation.php");
?>
```

### Include Navbar (In HTML)
```html
<!DOCTYPE html>
<html>
<head>...</head>
<body>

<?php include "../templates/navbar.php"; ?>

<h1>Page Title</h1>
...

</body>
</html>
```

### Include Footer
```html
<?php include "../templates/footer.php"; ?>
```

---

## 9. ERROR HANDLING

### Try-Catch Block
```php
try {
    // Code that might fail
    $result = mysqli_query($conn, $query);
    if(!$result){
        throw new Exception("Query failed: " . mysqli_error($conn));
    }
}
catch(Exception $e){
    // Handle error
    error_log($e->getMessage());
    echo "An error occurred. Please try again.";
}
```

### Check Before Using
```php
if($result){
    while($row = mysqli_fetch_assoc($result)){
        // Safe to use
    }
}
else {
    echo "Error: " . mysqli_error($conn);
}
```

---

## 10. HTML FORM ELEMENTS

### Text Input with Value
```html
<input 
    type="text" 
    name="name" 
    value="<?php echo htmlspecialchars($name ?? ''); ?>"
    required
>
```

### Dropdown with Selected
```html
<select name="blood_group">
    <option value="">Select</option>
    <?php
    $groups = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];
    foreach($groups as $g):
    ?>
        <option 
            value="<?php echo $g; ?>"
            <?php if(($blood_group ?? '') === $g) echo 'selected'; ?>
        >
            <?php echo $g; ?>
        </option>
    <?php endforeach; ?>
</select>
```

### Textarea with Value
```html
<textarea name="address">
<?php echo htmlspecialchars($address ?? ''); ?>
</textarea>
```

### Checkbox
```html
<input 
    type="checkbox" 
    name="active" 
    value="1"
    <?php if($active ?? false) echo 'checked'; ?>
>
```

### Radio Button
```html
<input 
    type="radio" 
    name="gender" 
    value="Male"
    <?php if(($gender ?? '') === 'Male') echo 'checked'; ?>
>
<input 
    type="radio" 
    name="gender" 
    value="Female"
    <?php if(($gender ?? '') === 'Female') echo 'checked'; ?>
>
```

---

## 11. STRING FUNCTIONS

### Trim
```php
$name = trim($name);  // Remove spaces from start/end
```

### Length
```php
if(strlen($password) < 8){
    $error = "Password too short";
}
```

### Contains
```php
if(strpos($email, "@") === false){
    $error = "Invalid email";
}
```

### Replace
```php
$text = str_replace("old", "new", $text);
```

### Substring
```php
$short = substr($text, 0, 10);  // First 10 chars
```

### To Uppercase/Lowercase
```php
$upper = strtoupper($name);
$lower = strtolower($name);
```

---

## 12. ARRAY FUNCTIONS

### Check if Value Exists
```php
if(in_array('A+', $blood_groups)){
    // Found
}
```

### Get All Keys
```php
$keys = array_keys($array);
```

### Get All Values
```php
$values = array_values($array);
```

### Count Elements
```php
$count = count($array);
```

### Loop Array
```php
foreach($array as $key => $value){
    echo $key . " = " . $value;
}
```

---

## 13. REGEX PATTERNS

### Letters Only
```php
/^[a-zA-Z]+$/
```

### Letters and Spaces
```php
/^[a-zA-Z\s]+$/
```

### Numbers Only
```php
/^[0-9]+$/
```

### Email
```php
/^[^\s@]+@[^\s@]+\.[^\s@]+$/
```

### Phone (10-15 digits)
```php
/^[0-9]{10,15}$/
```

---

## 14. COMMON MISTAKES & FIXES

### ❌ SQL Injection
```php
// WRONG
$query = "SELECT * FROM user WHERE id = $id";

// RIGHT
$query = "SELECT * FROM user WHERE id = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $id);
```

### ❌ XSS Attack
```php
// WRONG
echo "<p>" . $_POST['name'] . "</p>";

// RIGHT
echo "<p>" . htmlspecialchars($_POST['name']) . "</p>";
```

### ❌ Missing Session Check
```php
// WRONG - Anyone can access
echo "Welcome " . $_SESSION['name'];

// RIGHT
if(!isset($_SESSION['admin_id'])){
    header("Location: login.php");
    exit();
}
echo "Welcome " . $_SESSION['name'];
```

### ❌ No Input Validation
```php
// WRONG
$age = $_POST['age'];
mysqli_query($conn, "INSERT INTO users(age) VALUES('$age')");

// RIGHT
if(!is_numeric($age) || $age < 18){
    $error = "Invalid age";
}
```

### ❌ Unset Variable
```php
// WRONG
echo $undefined_var;  // Error!

// RIGHT
echo $undefined_var ?? "default";
// Or
if(isset($undefined_var)){
    echo $undefined_var;
}
```

---

## 15. CHECKLISTS

### Before Form Submit Button
- [ ] Add input validation
- [ ] Add error handling
- [ ] Sanitize output (htmlspecialchars)
- [ ] Use prepared statements
- [ ] Check user is logged in

### Before Database Insert
- [ ] All inputs validated
- [ ] Data is trimmed
- [ ] Use prepared statement
- [ ] Check if insert succeeded
- [ ] Show success/error message

### Before Displaying User Data
- [ ] Use htmlspecialchars()
- [ ] Check if variable exists
- [ ] Handle empty values

### Before Going Live
- [ ] All pages have session check
- [ ] All queries use prepared statements
- [ ] All inputs are validated
- [ ] All outputs are sanitized
- [ ] Error handling is in place
- [ ] No hardcoded passwords
- [ ] Tested in multiple browsers

---

## TEMPLATE TO COPY-PASTE

### New Page Template
```php
<?php
/**
 * [Page Title]
 * [Brief description]
 */

// Security & Setup
require_once("../admin/session_check.php");
require_once("../config/config.php");
require_once("../helpers/validation.php");

// Initialize
$error = null;
$success = null;

// Process Form
if(isset($_POST['submit'])){
    // Get data
    $field1 = trim($_POST['field1'] ?? '');
    
    // Validate
    if(empty($field1)){
        $error = "Field required";
    }
    else {
        // Insert using prepared statement
        $query = "INSERT INTO table(field1) VALUES(?)";
        $stmt = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt, "s", $field1);
        
        if(mysqli_stmt_execute($stmt)){
            $success = "Saved successfully";
        }
        else {
            $error = "Database error";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Page Title</title>
</head>
<body>

<?php include "../templates/navbar.php"; ?>

<?php if($error): ?>
    <div style="color: red;"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<?php if($success): ?>
    <div style="color: green;"><?php echo htmlspecialchars($success); ?></div>
<?php endif; ?>

<form method="POST">
    <input name="field1">
    <button type="submit" name="submit">Submit</button>
</form>

</body>
</html>
```

---

**Print this page and keep it nearby while coding! 📋**

